import React from 'react';
import { BrowserRouter as Router, Route, NavLink} from 'react-router-dom';
import ExpensesList from './Components/ExpensesList';
import ExpenseForm from './Components/ExpenseForm';
import ExpenseSummary from './Components/ExpenseSummary';
import './styles.css';

const App: React.FC = () => {
  return (
    <Router>
      <div>
        <nav>
          <ul>
            <li>
            <NavLink to='/new'
                className='nav-link'>
  Expenses List
</NavLink>

            </li>
            <li>
            <NavLink to='/new'
                className='nav-link'>
  Add New Expense
</NavLink>
            </li>
          </ul>
        </nav>

        <Route path="/" Component={ExpensesList} />
        <Route path="/add" Component={ExpenseForm} />
        <Route path="/summary" Component={ExpenseSummary} />
      </div>
    </Router>
  );
};

export default App;
