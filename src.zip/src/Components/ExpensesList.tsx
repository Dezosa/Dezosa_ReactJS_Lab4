import React, { useEffect, useState } from 'react';
import axios from 'axios';

interface Expense {
  id: number;
  payeeName: string;
  product: string;
  price: number;
  setDate: string;
}

const ExpensesList: React.FC = () => {
  const [expenses, setExpenses] = useState<Expense[]>([]);

  useEffect(() => {
    fetchExpenses();
  }, []);

  const fetchExpenses = async () => {
    try {
      const response = await axios.get<Expense[]>('http://localhost:3001/Expense');
      setExpenses(response.data);
    } catch (error) {
      console.error('Error fetching expenses:', error);
    }
  };

  return (
    <div>
      <h2>Expenses List</h2>
      <ul>
        {expenses.map((expense) => (
          <li key={expense.id}>
            <strong>Payee Name:</strong> {expense.payeeName}, <strong>Product:</strong> {expense.product}, <strong>Price:</strong> ${expense.price}, <strong>Date:</strong> {expense.setDate}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ExpensesList;
