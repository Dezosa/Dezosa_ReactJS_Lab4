import React, { useEffect, useState } from 'react';
import axios from 'axios';

interface Expense {
  id: number;
  payeeName: string;
  product: string;
  price: number;
  setDate: string;
}

const ExpenseSummary: React.FC = () => {
  const [expenses, setExpenses] = useState<Expense[]>([]);

  useEffect(() => {
    fetchExpenses();
  }, []);

  const fetchExpenses = async () => {
    try {
      const response = await axios.get<Expense[]>('http://localhost:3001/Expense');
      setExpenses(response.data);
    } catch (error) {
      console.error('Error fetching expenses:', error);
    }
  };

  const calculateTotalSpent = () => {
    return expenses.reduce((total, expense) => total + expense.price, 0);
  };

  // Implement your logic to calculate individual expenses and payment details here

  return (
    <div>
      <h2>Expense Summary</h2>
      <p>Total Spent: ${calculateTotalSpent()}</p>
      {/* Display individual expenses and payment details */}
    </div>
  );
};

export default ExpenseSummary;
