interface Expense{
    id:number;
    product:string;
    price:number;
    payeeName:string;
    setDate:string
}
import React, { useState } from 'react';
import axios from 'axios';

const ExpenseForm: React.FC = () => {
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();

    try {
      const response = await axios.post<Expense>('http://localhost:3001/Expense', {
        description,
        amount: Number(amount),
      });

      console.log('Expense added:', response.data);

      // Clear form inputs
      setDescription('');
      setAmount('');
    } catch (error) {
      console.error('Error adding expense:', error);
    }
  };

  return (
    <div>
      <h2>Add New Expense</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="description">Description: </label>
          <input
            type="text"
            id="description"
            value={description}
            onChange={(event) => setDescription(event.target.value)}
          />
        </div>
        <div>
          <label htmlFor="amount">Amount: </label>
          <input
            type="number"
            id="amount"
            value={amount}
            onChange={(event) => setAmount(event.target.value)}
          />
        </div>
        <button type="submit">Add Expense</button>
      </form>
    </div>
  );
};

export default ExpenseForm;
