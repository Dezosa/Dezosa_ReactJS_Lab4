export default interface Expense{
    id:number;
    product:string;
    price:number;
    payeeName:string;
    setDate:string
}